function validateIfEmpty(controlID) {
    var control = document.getElementById(controlID);

    if (control.value == "") {
        control.style.background = "rgba( 220, 116, 116, 0.166 )"
    } else {
        control.style.background = "white"
    }
}

function myfun() {
    var a = document.getElementById("password").value;
    var b = document.getElementById("password2").value;

    if (a == "") {
        document.getElementById("messages").innerHTML = "** Skriv inn passord"
        return false;
    } else if (a.length < 4) {
        document.getElementById("messages").innerHTML = "* Passordet må være lengre enn 4 karakterer"
        return false;
    } else if (a.length > 15) {
        document.getElementById("messages").innerHTML = "* Passordet må ha mindre enn 15 karakterer"
        return false;
    } else if (a != b) {
        document.getElementById("messages").innerHTML = "Passordet er ikke likt";
        return false;
    }

}
