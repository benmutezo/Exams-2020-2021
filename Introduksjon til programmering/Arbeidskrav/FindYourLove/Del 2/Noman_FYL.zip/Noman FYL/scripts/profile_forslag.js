
  var profiler = [
    {
        navn: "Marcus",
        alder: 27,
        kjønn: "mann",
        bakgrunn: "Norge",
        hobby: "Programmering",
        bilde: "./images/man1.jpg"
    },
    {
        navn: "Elias",
        alder: 22,
        kjønn: "mann",
        bakgrunn: "Kenya", 
        hobby: "Idrett, trening", 
        bilde: "./images/man2.jpg"
    },
    {
        navn: "Henrik",
        alder: 31,
        kjønn: "mann",
        bakgrunn: "Norge",
        hobby: "Fotografering",
        bilde: "./images/man3.JPG"
    },
    {
        navn: "Cecilie",
        alder: 29,
        kjønn: "kvinne",
        Bakgrunn: "Norge", 
        hobby: "Blogging",
        bilde: "./images/woman1.jpg"
    },
    {
        navn: "Emma",
        alder: 22,
        kjønn: "kvinne",
        bakgrunn: "USA",
        hobby: "Florist",
        bilde: "./images/woman2.jpg",
    },
    {
        navn: "Katarina",
        alder: 34,
        kjønn: "kvinne",
        bakgrunn: "Iran",
        hobby: "Baking",
        bilde: "./images/woman3.jpg"
    }
]

var gittAlder = document.getElementsByClassName("aldersfelt");
var gittKjonn = document.getElementsByClassName("input-gender");
var button = document.getElementsByClassName("findprofile");


function findProfile() {
    var onsketAlder = gittAlder[0].value;
    var onsketKjønn = gittKjonn[0].value.toLowerCase();
    
    var results = [];
    debugger;

    for (var i = 0; i < profiler.length; i++) {
        var profile = profiler[i];
        var profileAge = profile.alder;
        var profileGender = profile.kjønn;

        if (
            onsketAlder >= 25 &&
            profileAge >= 25 &&
            profileGender === onsketKjønn
        ) {
            results.push(profile);
        } else if (
            onsketAlder < 25 &&
            profileAge < 25 &&
            profileGender === onsketKjønn
        ) {
            results.push(profile);
        } 
        
    }
    var randomMatch = Math.floor(Math.random() * results.length);
    var match = results[randomMatch];
    document.getElementById("resultProfile").innerHTML = `
		<article>
			<div class="image-container">
				<img src="${match.bilde}" alt="picture"/>
			</div>
			<div class="informasjon-container">
				<p>Navn: ${match.navn}</p>
				<p>Alder: ${match.alder}år</p>
                <p>Bakgrunn: ${match.bakgrunn}</p>
                <p>Hobby: ${match.hobby}</p>
			</div>
		</article>
        `;
    console.log("Result: " + results[0].navn);
}