

function GetAllProfiles() {
    var profilomraade = document.getElementById("section-profiler");

    var profiler = [
        {
            navn: "Marcus",
            alder: 27,
            kjønn: "mann",
            bakgrunn: "Norge",
            hobby: "Programmering",
            bilde: "./images/man1.jpg"
        },
        {
            navn: "Elias",
            alder: 22,
            kjønn: "mann",
            bakgrunn: "Kenya", 
            hobby: "Idrett, trening", 
            bilde: "./images/man2.jpg"
        },
        {
            navn: "Henrik",
            alder: 31,
            kjønn: "mann",
            bakgrunn: "Norge",
            hobby: "Fotografering",
            bilde: "./images/man3.JPG"
        },
        {
            navn: "Mette",
            alder: 29,
            kjønn: "kvinne",
            bakgrunn: "Norge", 
            hobby: "Blogging",
            bilde: "./images/woman1.jpg"
        },
        {
            navn: "Emma",
            alder: 22,
            kjønn: "kvinne",
            bakgrunn: "USA",
            hobby: "Florist",
            bilde: "./images/woman2.jpg",
        },
        {
            navn: "Katarina",
            alder: 34,
            kjønn: "kvinne",
            bakgrunn: "Iran",
            hobby: "Baking",
            bilde: "./images/woman3.jpg"
        }
    ]

    var i;
    for (i = 0; i < profiler.length; i++) {
        profilomraade.innerHTML += `
				<article>
					<div class="image-container">
						<img src="${profiler[i].bilde}" alt="picture"/>
					</div>
					<div class="informasjon-container">
						<p><B>Navn</B>: ${profiler[i].navn}</p>
                        <p><B>Alder</B>: ${profiler[i].alder}</p>
						<p><B>Bakgrunn</B>: ${profiler[i].bakgrunn}</p>
						<p><B>Hobby</B>: ${profiler[i].hobby}</p>
					</div>
				</article>
			`
    }
}