
  var profiler = [
    {
        navn: "Marcus",
        alder: 27,
        kjønn: "mann",
        bakgrunn: "Norge",
        hobby: "Programmering",
        bilde: "./images/man1.jpg",
        likes: 47
    },
    {
        navn: "Elias",
        alder: 22,
        kjønn: "mann",
        bakgrunn: "Kenya", 
        hobby: "Idrett, trening", 
        bilde: "./images/man2.jpg",
        likes: 72
    },
    {
        navn: "Henrik",
        alder: 31,
        kjønn: "mann",
        bakgrunn: "Norge",
        hobby: "Fotografering",
        bilde: "./images/man3.JPG",
        likes: 13
    },
    {
        navn: "Mette",
        alder: 29,
        kjønn: "kvinne",
        Bakgrunn: "Norge", 
        hobby: "Blogging",
        bilde: "./images/woman1.jpg",
        likes: 63
    },
    {
        navn: "Emma",
        alder: 22,
        kjønn: "kvinne",
        bakgrunn: "USA",
        hobby: "Florist",
        bilde: "./images/woman2.jpg",
        likes: 82
    },
    {
        navn: "Katarina",
        alder: 34,
        kjønn: "kvinne",
        bakgrunn: "Iran",
        hobby: "Baking",
        bilde: "./images/woman3.jpg",
        likes: 38
    }
]

var sortedProfiles = profiler.sort(function(a, b){
    return b.likes - a.likes;
});
var PopularProfile = sortedProfiles[0];
console.log("value of temp: " + PopularProfile.likes);

document.getElementById("ukensProfile").innerHTML = `
		<div>
			<div class="image-container">
				<img src="${PopularProfile.bilde}" alt="Picture"/>
			</div>
			<div class="informasjon-container">
				<p>Navn: ${PopularProfile.navn}</p>
				<p>Alder: ${PopularProfile.alder}år</p>
                <p>Bakgrunn: ${PopularProfile.bakgrunn}</p>
                <p><b><h3>Likes: ${PopularProfile.likes}</h3></b></p>
                <p>Hobby: ${PopularProfile.hobby}</p>
			</div>
		</div>
        `;