public enum BallType {
    FOOTBALL, HANDBALL, BASKETBALL, VOLLEYBALL

}
