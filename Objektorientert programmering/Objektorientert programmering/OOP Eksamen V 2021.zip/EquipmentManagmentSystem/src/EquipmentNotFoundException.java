public class EquipmentNotFoundException extends Exception {
    public EquipmentNotFoundException(String message) {
        super(message);
    }
}
